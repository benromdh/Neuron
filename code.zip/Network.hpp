#ifndef NETWORK_H
#define NETWORK_H
#include "neurones.hpp"
#include <iostream>
#include <vector>

using namespace std;

class Network

{
	
	private :
		
		Neurone n1;
		Neurone n2;
		//vector<vector<Neurone>> Neurones(12500, vector<Neurone>(12500));

	public :
	
		void interaction();
		 
		
	
	
	
	
	
	
	
	
};















#endif
